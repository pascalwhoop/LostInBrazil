package pp2014.team32.server;

import pp2014.team32.server.comm.ClientConnectionHandler;
import pp2014.team32.comm.ClientObjectInputHandler;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * User: Pascal Brokmeier
 * Date: 25.04.14
 * Time: 13:26
 */
public class ServerMain {

    private final static Logger LOGGER = Logger.getLogger(ServerMain.class.getName());

    public static void main(String[] args) {


        //to initiate our ClientConnectionHandler
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    ClientConnectionHandler.init();
                } catch (IOException e) {
                    LOGGER.log(Level.SEVERE, e.getMessage(), e);

                    //this shouldn't happen, shutting down
                    e.printStackTrace();
                    System.exit(1);
                }
            }
        }).start();

        //to initiate our ClientObjectInputHandler
        new Thread(new Runnable() {
            @Override
            public void run() {
                ClientObjectInputHandler.init();
            }
        }).start();


    }

}
