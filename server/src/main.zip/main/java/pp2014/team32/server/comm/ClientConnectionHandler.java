package pp2014.team32.server.comm;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * User: Pascal
 * Date: 25.04.14
 * Time: 14:38
 * <p/>
 * Die Klasse, welche sich um die ankommenden Verbindungsanfragen der Benutzer kuemmert und diese verwaltet. Jeder socket wird in einer
 *
 * @author Pascal Brokmeier
 * @version 2014-05-12
 */
public class ClientConnectionHandler {

    private final static Logger LOGGER = Logger.getLogger(ClientConnectionHandler.class.getName());

    private static final int SERVER_PORT = 4567;
    private static final int INPUT_QUEUE_LENGTH = 1000;
    private static final int OUTPUT_QUEUE_LENGTH = 1000;
    private static final int SUPPORTED_USERS = 10;
    public static ServerSocket serverSocket;
    public static HashMap<String, Socket> userConnectionsMap = new HashMap<>();
    public static HashMap<String, Future> userThreadFutureMap = new HashMap<>();
    public static HashMap<String, ObjectOutputStream> userOutputObjectStreams = new HashMap<>();

    private static ThreadPoolExecutor clientOutputThreadPool = new ThreadPoolExecutor(SUPPORTED_USERS, SUPPORTED_USERS, 10, TimeUnit.MINUTES, new ArrayBlockingQueue<Runnable>(OUTPUT_QUEUE_LENGTH));
    private static ThreadPoolExecutor clientInputThreadPool = new ThreadPoolExecutor(SUPPORTED_USERS, SUPPORTED_USERS, 10, TimeUnit.MINUTES, new ArrayBlockingQueue<Runnable>(INPUT_QUEUE_LENGTH));


    /**
     * Die Methode welche zur Initiierung des ClientConnectionHandlers aufgerufen wird. Aktuell muss diese aus einem eigenen Thread aus gestartet werden
     * Vielleicht machen wir das spaeter auch selbst, sodass diese nicht in einem seperaten thread eingepackt sein muss..
     *
     * @throws IOException
     * @author pascal
     */
    public static void init() throws IOException {
        serverSocket = new ServerSocket(SERVER_PORT);
        handleIncomingConnections();
    }


    /**
     * Blockt und wartet auf neue Verbindungen auf dem socket. Sobald eine Verbindung geoeffnet wird, wird handleConnection aufgerufen und der socket uebergeben
     *
     * @author pascal
     */
    private static void handleIncomingConnections() {
        while (true) {
            try {
                handleConnection(serverSocket.accept());
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Logik, welche fuer neue Clients & deren sockets alle notwendigen ressourcen initiiert. Sie legt den Socket in unsere Map ab, legt
     * ObjectOutputStreams in einer Map ab und uebergibt den Threadpools die notwendigen Callables zum managen des neuen Clients.
     *
     * @param client the socket that was created for a specific client
     * @throws IOException
     * @throws ClassNotFoundException
     * @author pascal
     */
    public static void handleConnection(Socket client) throws IOException, ClassNotFoundException {
        LOGGER.info("Client connected: " + client.toString());


        ObjectOutputStream oos = new ObjectOutputStream(client.getOutputStream());
        Future future = clientInputThreadPool.submit(new ObjectStreamInputCallable(new ObjectInputStream(client.getInputStream()), "demoClient"));

        //TODO we need to do authorization and all that and then put the user into our system
        userConnectionsMap.put("demoClient", client);
        userOutputObjectStreams.put("demoClient", oos);
        userThreadFutureMap.put("demoClient", future);

        /*int i = 1000;
        while (!client.isClosed()) {
            try {
                Object o = ois.readObject();
                String receivedFromClient = (String) o;
                String response = "Server received: " + receivedFromClient + " and answers with this: " + i++;
                oos.writeObject(response);
                oos.flush();
            } catch (EOFException e) {
                //means the client closed the connection
                client.close();
                LOGGER.info("Client connection closed: " + client.toString());
            }
        }*/


    }

    /**
     * Diese
     *
     * @param username Der user fuer den ein Problem im Thread entstand. Wir beenden die Verbindung.
     * @author pascal
     */
    protected synchronized static void exceptionInThreadOccured(String username) {

        //TODO handle thread execution error for user and perform orderly shutdown tasks
        //handle different errors through different error types thrown

        //log exception
        Future future = userThreadFutureMap.get(username);
        try {
            future.get();
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, e.getMessage(), e);

        }

        //perform orderly shutdown
        try {
            Socket socket = userConnectionsMap.get(username);
            socket.close();
            connectionClosed(username);

        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, e.getMessage(), e);
        }


    }

    protected synchronized static void connectionClosed(String username) {
        userConnectionsMap.remove(username);
        userOutputObjectStreams.remove(username);
        userThreadFutureMap.remove(username);

    }
}
