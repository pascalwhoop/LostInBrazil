package pp2014.team32.server.comm;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * User: Pascal
 * Date: 13.05.14
 * Time: 17:05
 *
 * @author Pascal
 * @version 13.05.14
 */
public class ClientObjectInputHandler {

    private final static Logger LOGGER = Logger.getLogger(ClientObjectInputHandler.class.getName());


    private static final int QUEUE_SIZE = 10000;
    private static ArrayBlockingQueue<Object> objectQueue = new ArrayBlockingQueue<Object>(QUEUE_SIZE);

    public static synchronized void handleReceivedObject(Object o) {
        try{
            objectQueue.put(o);
        }catch (InterruptedException e ){
            LOGGER.log(Level.SEVERE, e.getMessage(), e);
        }
    }



    public static void init() {
        while (true) {
            try {
                Object o = objectQueue.take();

                //for now just the dummy end to test full blown multi threaded client server communication
                if (o instanceof String) {
                    String obj = (String) o;
                    System.out.println(obj);
                }
            } catch (InterruptedException e) {
                LOGGER.log(Level.SEVERE, e.getMessage(), e);
            }
        }
    }

}
