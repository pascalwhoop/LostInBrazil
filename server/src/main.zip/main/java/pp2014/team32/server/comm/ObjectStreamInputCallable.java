package pp2014.team32.server.comm;

import java.io.EOFException;
import java.io.ObjectInputStream;
import java.util.concurrent.Callable;
import java.util.logging.Logger;

/**
 * User: Pascal
 * Date: 12.05.14
 * Time: 21:51
 */
public class ObjectStreamInputCallable implements Callable {

    private final static Logger LOGGER = Logger.getLogger(ObjectStreamInputCallable.class.getName());

    private ObjectInputStream ois;
    private final String USERNAME;

    private boolean connectionClosed;


    public ObjectStreamInputCallable(ObjectInputStream ois, String username) {
        this.ois = ois;
        connectionClosed = false;
        this.USERNAME = username;

    }


    @Override
    public Object call() throws Exception {
        LOGGER.info("started reading input for user in thread with ID: " + Thread.currentThread().getId());

        while (!connectionClosed) {
            try{
                Object o = ois.readObject();
                LOGGER.info("received object from client " + USERNAME + " + in Thread: " + Thread.currentThread().getId());
                ClientObjectInputHandler.handleReceivedObject(o);
            }

            catch(EOFException e){
                //the inputStream is closed (EOF means socket closed)
                connectionClosed = true;
                ClientConnectionHandler.connectionClosed(USERNAME);
            }
            catch(Exception e){
                //something else happened. for now we will end thread and just act as if the socket was closed. error handling should be improved
                //TODO improve error handling for input connection errors
                connectionClosed = true;
                ClientConnectionHandler.exceptionInThreadOccured(USERNAME);
            }
        }
        //this callable doesnt need to return anything
        return null;
    }
}
