package pp2014.team32.server.comm;

import java.io.ObjectOutputStream;
import java.util.concurrent.Callable;

/**
 * User: Pascal
 * Date: 12.05.14
 * Time: 21:30
 */
public class ObjectStreamOutputCallable implements Callable {

    private ObjectOutputStream oos;
    private Object objToSend;

    public ObjectStreamOutputCallable(ObjectOutputStream oos, Object objToSend) {
        this.oos = oos;
        this.objToSend = objToSend;
    }

    @Override
    public Object call() throws Exception {
        oos.writeObject(objToSend);
        return null;
    }
}
